package com.example.criabotao;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;

public class MainActivity extends AppCompatActivity {

    // private Socket s;
    private EditText e1;
    // private PrintWriter writer;
    static String host,porta ;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //e1 = (EditText)findViewById(R.id.textViewMsg);

    }

    public void setaHost(View V){
        EditText editTextHost = findViewById(R.id.editTextHost);
        TextView textoMostrar = findViewById(R.id.textViewMostrar);
        host = editTextHost.getText().toString();
        textoMostrar.setText("Ip configurado na porta:6000" );
    }


    public void enviaSocketLigar(View V) {

        TextView textoMostrador = findViewById(R.id.textViewMostrador);
        TextView textoMostrar = findViewById(R.id.textViewMostrar);



       BackgroundTask b1 = new BackgroundTask();
       b1.execute("a");

         textoMostrador.setText("Ar condicionado Ligado " );
         textoMostrar.setText("A");
    }

    public void enviaSocketDesligar(View V) {

            TextView textoMostrador = findViewById(R.id.textViewMostrador);
            TextView textoMostrar = findViewById(R.id.textViewMostrar);



            BackgroundTask b1 = new BackgroundTask();
            b1.execute("b");

            textoMostrador.setText("Ar condicionado Desligado " );
            textoMostrar.setText("B");
        }


    public void enviaSocketAumentar(View V) {

        TextView textoMostrador = findViewById(R.id.textViewMostrador);
        TextView textoMostrar = findViewById(R.id.textViewMostrar);



        BackgroundTask b1 = new BackgroundTask();
        b1.execute("c");

        textoMostrador.setText("Temperatura Aumentada " );
        textoMostrar.setText("C");
    }

    public void enviaSocketDiminuir(View V) {

        TextView textoMostrador = findViewById(R.id.textViewMostrador);
        TextView textoMostrar = findViewById(R.id.textViewMostrar);



        BackgroundTask b1 = new BackgroundTask();
        b1.execute("d");

        textoMostrador.setText("Temperatura Diminuida " );
        textoMostrar.setText("D");
    }










    class BackgroundTask extends AsyncTask<String, Void, Void> {
        Socket s;
        PrintWriter writer;

        @Override
        protected Void doInBackground(String... voids) {
            try {

                String msgm = voids[0];

                s = new Socket(host, 6000);
                writer = new PrintWriter(s.getOutputStream());
                writer.write(msgm);
                writer.flush();
                writer.close();

                s.close();

                } catch (IOException e) {
                e.printStackTrace();
                       }

            return null;
         }
    }


}